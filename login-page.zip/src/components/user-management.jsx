"use client"

import { useState, useEffect } from "react"
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Chip,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Alert,
  Grid,
} from "@mui/material"
import { Add, Edit, Delete } from "@mui/icons-material"
import { useAuth } from "../contexts/auth-context"
import { userService } from "../services/user-service"
import { accessControl } from "../utils/access-control"
import { permissions } from "../data/mock-data"

function UserManagement() {
  const { user: currentUser } = useAuth()
  const [activeTab, setActiveTab] = useState(0)
  const [users, setUsers] = useState([])
  const [groups, setGroups] = useState([])
  const [loading, setLoading] = useState(true)
  const [editingUser, setEditingUser] = useState(null)
  const [editingGroup, setEditingGroup] = useState(null)
  const [showAddUser, setShowAddUser] = useState(false)
  const [showAddGroup, setShowAddGroup] = useState(false)
  const [deleteConfirmation, setDeleteConfirmation] = useState({ show: false, type: "", id: null, name: "" })

  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    role: "user",
    team: "Engineering",
    groups: ["Engineering Team"],
    permissions: ["read"],
  })

  const [newGroup, setNewGroup] = useState({
    name: "",
    description: "",
    permissions: [],
    team: null,
  })

  // Load data on component mount
  useEffect(() => {
    loadData()
  }, [currentUser])

  const loadData = async () => {
    setLoading(true)
    try {
      const [usersData, groupsData] = await Promise.all([
        currentUser.role === "super_admin" ? userService.getUsers() : userService.getUsersByTeam(currentUser.team),
        currentUser.role === "super_admin" ? userService.getGroups() : userService.getGroupsByTeam(currentUser.team),
      ])

      setUsers(usersData)
      setGroups(groupsData)
    } catch (error) {
      console.error("Error loading data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddUser = async (e) => {
    e.preventDefault()
    try {
      const result = await userService.createUser(newUser)
      if (result.success) {
        setUsers([...users, result.user])
        setNewUser({
          name: "",
          email: "",
          role: "user",
          team: "Engineering",
          groups: ["Engineering Team"],
          permissions: ["read"],
        })
        setShowAddUser(false)
      }
    } catch (error) {
      console.error("Error creating user:", error)
    }
  }

  const handleSaveUser = async () => {
    try {
      const result = await userService.updateUser(editingUser.id, editingUser)
      if (result.success) {
        setUsers(users.map((user) => (user.id === editingUser.id ? result.user : user)))
        setEditingUser(null)
      }
    } catch (error) {
      console.error("Error updating user:", error)
    }
  }

  const confirmDeleteUser = async () => {
    try {
      const result = await userService.deleteUser(deleteConfirmation.id)
      if (result.success) {
        setUsers(users.filter((user) => user.id !== deleteConfirmation.id))
        setDeleteConfirmation({ show: false, type: "", id: null, name: "" })
      }
    } catch (error) {
      console.error("Error deleting user:", error)
    }
  }

  const handleAddGroup = async (e) => {
    e.preventDefault()
    try {
      const result = await userService.createGroup(newGroup)
      if (result.success) {
        setGroups([...groups, result.group])
        setNewGroup({
          name: "",
          description: "",
          permissions: [],
          team: null,
        })
        setShowAddGroup(false)
      }
    } catch (error) {
      console.error("Error creating group:", error)
    }
  }

  const handleSaveGroup = async () => {
    try {
      const result = await userService.updateGroup(editingGroup.id, editingGroup)
      if (result.success) {
        setGroups(groups.map((group) => (group.id === editingGroup.id ? result.group : group)))
        setEditingGroup(null)
      }
    } catch (error) {
      console.error("Error updating group:", error)
    }
  }

  const confirmDeleteGroup = async () => {
    try {
      const result = await userService.deleteGroup(deleteConfirmation.id)
      if (result.success) {
        setGroups(groups.filter((group) => group.id !== deleteConfirmation.id))
        setDeleteConfirmation({ show: false, type: "", id: null, name: "" })
      }
    } catch (error) {
      console.error("Error deleting group:", error)
    }
  }

  // Helper functions
  const handleEditUser = (user) => setEditingUser({ ...user })
  const handleEditGroup = (group) => setEditingGroup({ ...group })

  const handleDeleteUser = (userId) => {
    const user = users.find((u) => u.id === userId)
    setDeleteConfirmation({ show: true, type: "user", id: userId, name: user.name })
  }

  const handleDeleteGroup = (groupId) => {
    const group = groups.find((g) => g.id === groupId)
    setDeleteConfirmation({ show: true, type: "group", id: groupId, name: group.name })
  }

  const cancelDelete = () => {
    setDeleteConfirmation({ show: false, type: "", id: null, name: "" })
  }

  const toggleUserGroup = (groupName) => {
    if (editingUser.groups.includes(groupName)) {
      setEditingUser({
        ...editingUser,
        groups: editingUser.groups.filter((g) => g !== groupName),
      })
    } else {
      setEditingUser({
        ...editingUser,
        groups: [...editingUser.groups, groupName],
      })
    }
  }

  const toggleUserPermission = (permissionName) => {
    if (editingUser.permissions.includes(permissionName)) {
      setEditingUser({
        ...editingUser,
        permissions: editingUser.permissions.filter((p) => p !== permissionName),
      })
    } else {
      setEditingUser({
        ...editingUser,
        permissions: [...editingUser.permissions, permissionName],
      })
    }
  }

  const selectAllGroups = () => {
    setEditingUser({ ...editingUser, groups: groups.map((g) => g.name) })
  }

  const deselectAllGroups = () => {
    setEditingUser({ ...editingUser, groups: [] })
  }

  const selectAllPermissions = () => {
    setEditingUser({ ...editingUser, permissions: permissions.map((p) => p.name) })
  }

  const deselectAllPermissions = () => {
    setEditingUser({ ...editingUser, permissions: [] })
  }

  const toggleGroupPermission = (permissionName) => {
    if (editingGroup.permissions.includes(permissionName)) {
      setEditingGroup({
        ...editingGroup,
        permissions: editingGroup.permissions.filter((p) => p !== permissionName),
      })
    } else {
      setEditingGroup({
        ...editingGroup,
        permissions: [...editingGroup.permissions, permissionName],
      })
    }
  }

  const selectAllGroupPermissions = () => {
    setEditingGroup({ ...editingGroup, permissions: permissions.map((p) => p.name) })
  }

  const deselectAllGroupPermissions = () => {
    setEditingGroup({ ...editingGroup, permissions: [] })
  }

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", py: 4 }}>
        <CircularProgress />
        <Typography variant="h6" sx={{ ml: 2 }}>
          Loading...
        </Typography>
      </Box>
    )
  }

  const getRoleChip = (role) => {
    const config = {
      super_admin: { label: "Super Admin", color: "error" },
      team_admin: { label: "Team Admin", color: "warning" },
      user: { label: "User", color: "success" },
    }
    const { label, color } = config[role] || config.user
    return <Chip label={label} size="small" color={color} />
  }

  const renderUsersTab = () => (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Box>
          <Typography variant="h6">
            {currentUser.role === "super_admin"
              ? `All Users (${users.length})`
              : `${currentUser.team} Team Users (${users.length})`}
          </Typography>
          {currentUser.role === "team_admin" && (
            <Typography variant="body2" color="text.secondary">
              You can only manage users from your team
            </Typography>
          )}
        </Box>
        {accessControl.canCreateUsers(currentUser) && (
          <Button variant="contained" startIcon={<Add />} onClick={() => setShowAddUser(true)}>
            Add User
          </Button>
        )}
      </Box>

      {/* Users List */}
      <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {users.map((user) => (
          <Card key={user.id} variant="outlined">
            <CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <Box sx={{ flex: 1 }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
                    <Typography variant="h6">{user.name}</Typography>
                    {getRoleChip(user.role)}
                    {user.team && <Chip label={user.team} size="small" color="info" variant="outlined" />}
                  </Box>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {user.email}
                  </Typography>

                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <Typography variant="subtitle2" sx={{ fontWeight: "medium", mb: 1 }}>
                        Groups
                      </Typography>
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                        {user.groups?.map((group) => (
                          <Chip key={group} label={group} size="small" color="primary" variant="outlined" />
                        ))}
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="subtitle2" sx={{ fontWeight: "medium", mb: 1 }}>
                        Permissions
                      </Typography>
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                        {user.permissions?.map((permission) => (
                          <Chip key={permission} label={permission} size="small" color="secondary" variant="outlined" />
                        ))}
                      </Box>
                    </Grid>
                  </Grid>
                </Box>
                <Box sx={{ display: "flex", gap: 1 }}>
                  {accessControl.canEditUser(currentUser, user) && (
                    <Button size="small" variant="outlined" startIcon={<Edit />} onClick={() => handleEditUser(user)}>
                      Edit
                    </Button>
                  )}
                  {accessControl.canDeleteUser(currentUser, user) && (
                    <Button
                      size="small"
                      variant="outlined"
                      color="error"
                      startIcon={<Delete />}
                      onClick={() => handleDeleteUser(user.id)}
                    >
                      Delete
                    </Button>
                  )}
                  {!accessControl.canEditUser(currentUser, user) && !accessControl.canDeleteUser(currentUser, user) && (
                    <Chip label="View Only" size="small" variant="outlined" />
                  )}
                </Box>
              </Box>
            </CardContent>
          </Card>
        ))}
      </Box>

      {users.length === 0 && (
        <Box sx={{ textAlign: "center", py: 4 }}>
          <Typography variant="body1" color="text.secondary">
            {currentUser.role === "team_admin" ? "No users found in your team" : "No users found"}
          </Typography>
        </Box>
      )}
    </Box>
  )

  const renderGroupsTab = () => (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Box>
          <Typography variant="h6">
            {currentUser.role === "super_admin"
              ? `All Groups (${groups.length})`
              : `Available Groups (${groups.length})`}
          </Typography>
          {currentUser.role === "team_admin" && (
            <Typography variant="body2" color="text.secondary">
              You can only view groups for your team
            </Typography>
          )}
        </Box>
        {accessControl.canManageGroups(currentUser) && (
          <Button variant="contained" startIcon={<Add />} onClick={() => setShowAddGroup(true)}>
            Create Group
          </Button>
        )}
      </Box>

      {/* Groups List */}
      <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {groups.map((group) => (
          <Card key={group.id} variant="outlined">
            <CardContent>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <Box sx={{ flex: 1 }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
                    <Typography variant="h6">{group.name}</Typography>
                    <Chip label={`${group.userCount} users`} size="small" color="primary" variant="outlined" />
                    {group.team && (
                      <Chip label={`${group.team} Team`} size="small" color="secondary" variant="outlined" />
                    )}
                  </Box>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {group.description}
                  </Typography>

                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: "medium", mb: 1 }}>
                      Permissions
                    </Typography>
                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                      {group.permissions?.map((permission) => (
                        <Chip key={permission} label={permission} size="small" color="secondary" variant="outlined" />
                      ))}
                    </Box>
                  </Box>
                </Box>
                <Box sx={{ display: "flex", gap: 1 }}>
                  {accessControl.canManageGroups(currentUser) && (
                    <>
                      <Button
                        size="small"
                        variant="outlined"
                        startIcon={<Edit />}
                        onClick={() => handleEditGroup(group)}
                      >
                        Edit
                      </Button>
                      <Button
                        size="small"
                        variant="outlined"
                        color="error"
                        startIcon={<Delete />}
                        onClick={() => handleDeleteGroup(group.id)}
                      >
                        Delete
                      </Button>
                    </>
                  )}
                  {!accessControl.canManageGroups(currentUser) && (
                    <Chip label="View Only" size="small" variant="outlined" />
                  )}
                </Box>
              </Box>
            </CardContent>
          </Card>
        ))}
      </Box>

      {groups.length === 0 && (
        <Box sx={{ textAlign: "center", py: 4 }}>
          <Typography variant="body1" color="text.secondary">
            No groups available
          </Typography>
          {accessControl.canManageGroups(currentUser) && (
            <Button variant="contained" startIcon={<Add />} onClick={() => setShowAddGroup(true)} sx={{ mt: 2 }}>
              Create Your First Group
            </Button>
          )}
        </Box>
      )}
    </Box>
  )

  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
      <Typography variant="h4" component="h2" sx={{ fontWeight: "bold" }}>
        {currentUser.role === "super_admin" ? "User Management" : `${currentUser.team} Team Management`}
      </Typography>

      {/* Styled Tab Navigation */}
      <Box
        sx={{
          borderBottom: 1,
          borderColor: "divider",
          mb: 3,
        }}
      >
        <Box sx={{ display: "flex", gap: 0 }}>
          <Button
            variant="text"
            onClick={() => {
              console.log("Switching to Users tab")
              setActiveTab(0)
            }}
            sx={{
              minWidth: 150,
              py: 1.5,
              px: 3,
              borderRadius: 0,
              borderBottom: activeTab === 0 ? 2 : 0,
              borderBottomColor: activeTab === 0 ? "primary.main" : "transparent",
              color: activeTab === 0 ? "primary.main" : "text.secondary",
              fontWeight: activeTab === 0 ? 600 : 400,
              textTransform: "none",
              "&:hover": {
                backgroundColor: "action.hover",
                borderBottomColor: activeTab === 0 ? "primary.main" : "action.hover",
              },
            }}
          >
            Users
          </Button>
          <Button
            variant="text"
            onClick={() => {
              console.log("Switching to Groups tab")
              setActiveTab(1)
            }}
            sx={{
              minWidth: 150,
              py: 1.5,
              px: 3,
              borderRadius: 0,
              borderBottom: activeTab === 1 ? 2 : 0,
              borderBottomColor: activeTab === 1 ? "primary.main" : "transparent",
              color: activeTab === 1 ? "primary.main" : "text.secondary",
              fontWeight: activeTab === 1 ? 600 : 400,
              textTransform: "none",
              "&:hover": {
                backgroundColor: "action.hover",
                borderBottomColor: activeTab === 1 ? "primary.main" : "action.hover",
              },
            }}
          >
            Groups & Permissions
          </Button>
        </Box>
      </Box>

      {/* Tab Content */}
      {activeTab === 0 ? renderUsersTab() : renderGroupsTab()}

      {/* Add User Dialog */}
      <Dialog open={showAddUser} onClose={() => setShowAddUser(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add New User</DialogTitle>
        <form onSubmit={handleAddUser}>
          <DialogContent>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
              <TextField
                fullWidth
                label="Name"
                value={newUser.name}
                onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                required
              />
              <TextField
                fullWidth
                label="Email"
                type="email"
                value={newUser.email}
                onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                required
              />
              <FormControl fullWidth>
                <InputLabel>Role</InputLabel>
                <Select
                  value={newUser.role}
                  label="Role"
                  onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                >
                  <MenuItem value="user">User</MenuItem>
                  <MenuItem value="team_admin">Team Admin</MenuItem>
                  <MenuItem value="super_admin">Super Admin</MenuItem>
                </Select>
              </FormControl>
              <FormControl fullWidth>
                <InputLabel>Team</InputLabel>
                <Select
                  value={newUser.team}
                  label="Team"
                  onChange={(e) => setNewUser({ ...newUser, team: e.target.value })}
                >
                  <MenuItem value="">No Team</MenuItem>
                  <MenuItem value="Engineering">Engineering</MenuItem>
                  <MenuItem value="Marketing">Marketing</MenuItem>
                  <MenuItem value="Sales">Sales</MenuItem>
                  <MenuItem value="Support">Support</MenuItem>
                  <MenuItem value="Finance">Finance</MenuItem>
                </Select>
              </FormControl>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowAddUser(false)}>Cancel</Button>
            <Button type="submit" variant="contained">
              Add User
            </Button>
          </DialogActions>
        </form>
      </Dialog>

      {/* Add Group Dialog */}
      <Dialog open={showAddGroup} onClose={() => setShowAddGroup(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create New Group</DialogTitle>
        <form onSubmit={handleAddGroup}>
          <DialogContent>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
              <TextField
                fullWidth
                label="Group Name"
                value={newGroup.name}
                onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
                required
              />
              <TextField
                fullWidth
                label="Description"
                value={newGroup.description}
                onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
                required
              />
              <FormControl fullWidth>
                <InputLabel>Team (Optional)</InputLabel>
                <Select
                  value={newGroup.team || ""}
                  label="Team (Optional)"
                  onChange={(e) => setNewGroup({ ...newGroup, team: e.target.value })}
                >
                  <MenuItem value="">All Teams</MenuItem>
                  <MenuItem value="Engineering">Engineering</MenuItem>
                  <MenuItem value="Marketing">Marketing</MenuItem>
                  <MenuItem value="Sales">Sales</MenuItem>
                  <MenuItem value="Support">Support</MenuItem>
                  <MenuItem value="Finance">Finance</MenuItem>
                </Select>
              </FormControl>
              <Box>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Permissions
                </Typography>
                <FormGroup>
                  {permissions.map((permission) => (
                    <FormControlLabel
                      key={permission.id}
                      control={
                        <Checkbox
                          checked={newGroup.permissions.includes(permission.name)}
                          onChange={() => {
                            if (newGroup.permissions.includes(permission.name)) {
                              setNewGroup({
                                ...newGroup,
                                permissions: newGroup.permissions.filter((p) => p !== permission.name),
                              })
                            } else {
                              setNewGroup({
                                ...newGroup,
                                permissions: [...newGroup.permissions, permission.name],
                              })
                            }
                          }}
                        />
                      }
                      label={permission.name}
                    />
                  ))}
                </FormGroup>
              </Box>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setShowAddGroup(false)}>Cancel</Button>
            <Button type="submit" variant="contained">
              Create Group
            </Button>
          </DialogActions>
        </form>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={!!editingUser} onClose={() => setEditingUser(null)} maxWidth="md" fullWidth>
        <DialogTitle>Edit User: {editingUser?.name}</DialogTitle>
        <DialogContent>
          {editingUser && (
            <Box sx={{ display: "flex", flexDirection: "column", gap: 3, pt: 1 }}>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Name"
                    value={editingUser.name}
                    onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Email"
                    type="email"
                    value={editingUser.email}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                  />
                </Grid>
              </Grid>

              {currentUser.role === "super_admin" && (
                <FormControl fullWidth>
                  <InputLabel>Team</InputLabel>
                  <Select
                    value={editingUser.team || ""}
                    label="Team"
                    onChange={(e) => setEditingUser({ ...editingUser, team: e.target.value })}
                  >
                    <MenuItem value="">No Team</MenuItem>
                    <MenuItem value="Engineering">Engineering</MenuItem>
                    <MenuItem value="Marketing">Marketing</MenuItem>
                    <MenuItem value="Sales">Sales</MenuItem>
                    <MenuItem value="Support">Support</MenuItem>
                    <MenuItem value="Finance">Finance</MenuItem>
                  </Select>
                </FormControl>
              )}

              <Grid container spacing={3}>
                <Grid item xs={6}>
                  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                    <Typography variant="subtitle2">Groups</Typography>
                    <Box>
                      <Button size="small" onClick={selectAllGroups}>
                        Select All
                      </Button>
                      <Button size="small" onClick={deselectAllGroups}>
                        Deselect All
                      </Button>
                    </Box>
                  </Box>
                  <Box
                    sx={{ maxHeight: 200, overflow: "auto", border: 1, borderColor: "divider", borderRadius: 1, p: 1 }}
                  >
                    <FormGroup>
                      {groups.map((group) => (
                        <FormControlLabel
                          key={group.id}
                          control={
                            <Checkbox
                              checked={editingUser.groups?.includes(group.name) || false}
                              onChange={() => toggleUserGroup(group.name)}
                            />
                          }
                          label={
                            <Box>
                              <Typography variant="body2">{group.name}</Typography>
                              <Typography variant="caption" color="text.secondary">
                                {group.description}
                              </Typography>
                            </Box>
                          }
                        />
                      ))}
                    </FormGroup>
                  </Box>
                </Grid>

                <Grid item xs={6}>
                  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                    <Typography variant="subtitle2">Permissions</Typography>
                    <Box>
                      <Button size="small" onClick={selectAllPermissions}>
                        Select All
                      </Button>
                      <Button size="small" onClick={deselectAllPermissions}>
                        Deselect All
                      </Button>
                    </Box>
                  </Box>
                  <Box
                    sx={{ maxHeight: 200, overflow: "auto", border: 1, borderColor: "divider", borderRadius: 1, p: 1 }}
                  >
                    <FormGroup>
                      {permissions.map((permission) => {
                        const isRestricted = accessControl
                          .getRestrictedPermissions(currentUser)
                          .includes(permission.name)
                        return (
                          <FormControlLabel
                            key={permission.id}
                            control={
                              <Checkbox
                                checked={editingUser.permissions?.includes(permission.name) || false}
                                onChange={() => toggleUserPermission(permission.name)}
                                disabled={isRestricted}
                              />
                            }
                            label={
                              <Box>
                                <Typography variant="body2">
                                  {permission.name}
                                  {isRestricted && (
                                    <Chip label="Restricted" size="small" color="error" sx={{ ml: 1 }} />
                                  )}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">
                                  {permission.description}
                                </Typography>
                              </Box>
                            }
                          />
                        )
                      })}
                    </FormGroup>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditingUser(null)}>Cancel</Button>
          <Button onClick={handleSaveUser} variant="contained">
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Group Dialog */}
      <Dialog open={!!editingGroup} onClose={() => setEditingGroup(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Edit Group: {editingGroup?.name}</DialogTitle>
        <DialogContent>
          {editingGroup && (
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
              <TextField
                fullWidth
                label="Group Name"
                value={editingGroup.name}
                onChange={(e) => setEditingGroup({ ...editingGroup, name: e.target.value })}
              />
              <TextField
                fullWidth
                label="Description"
                value={editingGroup.description}
                onChange={(e) => setEditingGroup({ ...editingGroup, description: e.target.value })}
              />
              <FormControl fullWidth>
                <InputLabel>Team (Optional)</InputLabel>
                <Select
                  value={editingGroup.team || ""}
                  label="Team (Optional)"
                  onChange={(e) => setEditingGroup({ ...editingGroup, team: e.target.value })}
                >
                  <MenuItem value="">All Teams</MenuItem>
                  <MenuItem value="Engineering">Engineering</MenuItem>
                  <MenuItem value="Marketing">Marketing</MenuItem>
                  <MenuItem value="Sales">Sales</MenuItem>
                  <MenuItem value="Support">Support</MenuItem>
                  <MenuItem value="Finance">Finance</MenuItem>
                </Select>
              </FormControl>
              <Box>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
                  <Typography variant="subtitle2">Permissions</Typography>
                  <Box>
                    <Button size="small" onClick={selectAllGroupPermissions}>
                      Select All
                    </Button>
                    <Button size="small" onClick={deselectAllGroupPermissions}>
                      Deselect All
                    </Button>
                  </Box>
                </Box>
                <Box
                  sx={{ maxHeight: 200, overflow: "auto", border: 1, borderColor: "divider", borderRadius: 1, p: 1 }}
                >
                  <FormGroup>
                    {permissions.map((permission) => (
                      <FormControlLabel
                        key={permission.id}
                        control={
                          <Checkbox
                            checked={editingGroup.permissions?.includes(permission.name) || false}
                            onChange={() => toggleGroupPermission(permission.name)}
                          />
                        }
                        label={
                          <Box>
                            <Typography variant="body2">{permission.name}</Typography>
                            <Typography variant="caption" color="text.secondary">
                              {permission.description}
                            </Typography>
                          </Box>
                        }
                      />
                    ))}
                  </FormGroup>
                </Box>
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditingGroup(null)}>Cancel</Button>
          <Button onClick={handleSaveGroup} variant="contained">
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteConfirmation.show} onClose={cancelDelete}>
        <DialogTitle sx={{ color: "error.main" }}>Confirm Deletion</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete the {deleteConfirmation.type} "{deleteConfirmation.name}"?
          </Typography>
          {deleteConfirmation.type === "group" && (
            <Alert severity="warning" sx={{ mt: 2 }}>
              ⚠️ Warning: Users assigned to this group may lose access permissions.
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={cancelDelete}>Cancel</Button>
          <Button
            onClick={deleteConfirmation.type === "user" ? confirmDeleteUser : confirmDeleteGroup}
            color="error"
            variant="contained"
          >
            Delete {deleteConfirmation.type === "user" ? "User" : "Group"}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

// Export both named and default exports to handle different import styles
export { UserManagement }
export default UserManagement
