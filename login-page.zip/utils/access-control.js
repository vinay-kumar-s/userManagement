// Access control utility functions
export const accessControl = {
  canEditUser(currentUser, targetUser) {
    if (currentUser.role === "super_admin") return true
    if (currentUser.role === "team_admin" && targetUser.team === currentUser.team) return true
    return false
  },

  canDeleteUser(currentUser, targetUser) {
    if (currentUser.role === "super_admin") return true
    if (currentUser.role === "team_admin" && targetUser.team === currentUser.team && targetUser.role !== "team_admin")
      return true
    return false
  },

  canManageGroups(currentUser) {
    return currentUser.role === "super_admin"
  },

  canCreateUsers(currentUser) {
    return currentUser.role === "super_admin"
  },

  getFilteredUsers(users, currentUser) {
    if (currentUser.role === "super_admin") {
      return users // Super admins can see all users
    } else if (currentUser.role === "team_admin") {
      return users.filter((user) => user.team === currentUser.team) // Team admins only see their team
    }
    return [] // Regular users shouldn't access this
  },

  getFilteredGroups(groups, currentUser) {
    if (currentUser.role === "super_admin") {
      return groups // Super admins can see all groups
    } else if (currentUser.role === "team_admin") {
      return groups.filter((group) => group.team === currentUser.team || group.team === null) // Team admins see their team groups + global groups
    }
    return []
  },

  getRestrictedPermissions(currentUser) {
    if (currentUser.role === "team_admin") {
      return ["manage_users", "system_admin", "manage_teams"]
    }
    return []
  },
}
