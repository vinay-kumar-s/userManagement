"use client"

import { useState } from "react"
import { Box, AppBar, Toolbar, Typography, Button, Container, Chip } from "@mui/material"
import { Search, People, Logout } from "@mui/icons-material"
import { useAuth } from "../contexts/auth-context"
import { SearchPage } from "./search-page"
import { UserManagement } from "./user-management"

export function Dashboard() {
  const { user, logout } = useAuth()
  const [currentPage, setCurrentPage] = useState("search")

  const handleLogout = async () => {
    try {
      await logout()
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  const getRoleLabel = (role) => {
    switch (role) {
      case "super_admin":
        return "Super Admin"
      case "team_admin":
        return "Team Admin"
      default:
        return "User"
    }
  }

  const getRoleColor = (role) => {
    switch (role) {
      case "super_admin":
        return "error"
      case "team_admin":
        return "warning"
      default:
        return "success"
    }
  }

  return (
    <Box sx={{ minHeight: "100vh", backgroundColor: "grey.50" }}>
      {/* Navigation Header */}
      <AppBar position="static" color="default" elevation={1}>
        <Toolbar>
          <Typography variant="h6" component="h1" sx={{ fontWeight: "bold", mr: 4 }}>
            Dashboard
          </Typography>

          <Box sx={{ display: "flex", gap: 1, mr: "auto" }}>
            <Button
              variant={currentPage === "search" ? "contained" : "text"}
              startIcon={<Search />}
              onClick={() => setCurrentPage("search")}
            >
              Search
            </Button>
            {(user.role === "super_admin" || user.role === "team_admin") && (
              <Button
                variant={currentPage === "users" ? "contained" : "text"}
                startIcon={<People />}
                onClick={() => setCurrentPage("users")}
              >
                User Management
              </Button>
            )}
          </Box>

          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Typography variant="body2" color="text.secondary">
                Welcome, {user.name}
              </Typography>
              <Chip label={getRoleLabel(user.role)} size="small" color={getRoleColor(user.role)} variant="outlined" />
              {user.team && <Chip label={user.team} size="small" color="info" variant="outlined" />}
            </Box>
            <Button variant="outlined" startIcon={<Logout />} onClick={handleLogout}>
              Logout
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Main Content */}
      <Container maxWidth="xl" sx={{ py: 4 }}>
        {currentPage === "search" && <SearchPage />}
        {currentPage === "users" && (user.role === "super_admin" || user.role === "team_admin") && <UserManagement />}
      </Container>
    </Box>
  )
}
