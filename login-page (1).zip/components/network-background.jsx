"use client"

import { useState, useEffect } from "react"

export function NetworkBackground() {
  const [nodes, setNodes] = useState([])
  const [connections, setConnections] = useState([])

  useEffect(() => {
    // Generate random nodes
    const generateNodes = () => {
      const newNodes = []
      for (let i = 0; i < 50; i++) {
        newNodes.push({
          id: i,
          x: Math.random() * 100,
          y: Math.random() * 100,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          size: Math.random() * 3 + 1,
        })
      }
      return newNodes
    }

    // Generate connections between nearby nodes
    const generateConnections = (nodes) => {
      const newConnections = []
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x
          const dy = nodes[i].y - nodes[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)
          if (distance < 15) {
            newConnections.push({
              from: i,
              to: j,
              opacity: Math.max(0, 1 - distance / 15),
            })
          }
        }
      }
      return newConnections
    }

    const initialNodes = generateNodes()
    setNodes(initialNodes)
    setConnections(generateConnections(initialNodes))

    // Animation loop
    const animate = () => {
      setNodes((prevNodes) => {
        const newNodes = prevNodes.map((node) => {
          let newX = node.x + node.vx
          let newY = node.y + node.vy
          let newVx = node.vx
          let newVy = node.vy

          // Bounce off edges
          if (newX <= 0 || newX >= 100) newVx = -newVx
          if (newY <= 0 || newY >= 100) newVy = -newVy

          newX = Math.max(0, Math.min(100, newX))
          newY = Math.max(0, Math.min(100, newY))

          return { ...node, x: newX, y: newY, vx: newVx, vy: newVy }
        })

        // Update connections
        setConnections(generateConnections(newNodes))
        return newNodes
      })
    }

    const interval = setInterval(animate, 100)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="absolute inset-0 overflow-hidden">
      <svg className="w-full h-full" style={{ background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)" }}>
        {/* Grid pattern */}
        <defs>
          <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
            <path d="M 50 0 L 0 0 0 50" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />

        {/* Connections */}
        {connections.map((connection, index) => {
          const fromNode = nodes[connection.from]
          const toNode = nodes[connection.to]
          if (!fromNode || !toNode) return null

          return (
            <line
              key={index}
              x1={`${fromNode.x}%`}
              y1={`${fromNode.y}%`}
              x2={`${toNode.x}%`}
              y2={`${toNode.y}%`}
              stroke="rgba(255,255,255,0.3)"
              strokeWidth="1"
              opacity={connection.opacity}
            />
          )
        })}

        {/* Nodes */}
        {nodes.map((node) => (
          <circle
            key={node.id}
            cx={`${node.x}%`}
            cy={`${node.y}%`}
            r={node.size}
            fill="rgba(255,255,255,0.8)"
            className="animate-pulse"
          />
        ))}

        {/* Floating particles */}
        <g>
          {[...Array(20)].map((_, i) => (
            <circle
              key={`particle-${i}`}
              cx={`${(i * 5 + 10) % 100}%`}
              cy={`${(i * 7 + 20) % 100}%`}
              r="1"
              fill="rgba(255,255,255,0.4)"
              className="animate-bounce"
              style={{
                animationDelay: `${i * 0.2}s`,
                animationDuration: `${2 + i * 0.1}s`,
              }}
            />
          ))}
        </g>
      </svg>

      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-purple-900/20 to-indigo-900/20"></div>

      {/* Tech elements */}
      <div className="absolute top-10 left-10 text-white/20 text-6xl font-mono">{"{ }"}</div>
      <div className="absolute bottom-10 right-10 text-white/20 text-4xl font-mono">&lt;/&gt;</div>
      <div className="absolute top-1/4 right-20 text-white/20 text-2xl font-mono">01010101</div>
      <div className="absolute bottom-1/4 left-20 text-white/20 text-2xl font-mono">API_v2.0</div>
    </div>
  )
}
