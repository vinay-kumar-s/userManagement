"use client"

import { useState } from "react"
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  IconButton,
  InputAdornment,
  Alert,
  CircularProgress,
} from "@mui/material"
import { Visibility, VisibilityOff } from "@mui/icons-material"
import { useAuth } from "../contexts/auth-context"
import { authService } from "../services/auth-service"
import { NetworkBackground } from "./network-background"

export function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const result = await authService.login(email, password)

      if (result.success) {
        login(result.user)
      } else {
        setError(result.error)
      }
    } catch (err) {
      setError("An error occurred during login")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Animated Network Background */}
      <NetworkBackground />

      {/* Login Card */}
      <Box sx={{ position: "relative", zIndex: 10, width: "100%", maxWidth: 400, px: 2 }}>
        <Card
          sx={{
            backdropFilter: "blur(10px)",
            backgroundColor: "rgba(255, 255, 255, 0.95)",
            boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
            border: "none",
          }}
        >
          <CardContent sx={{ p: 4 }}>
            {/* Logo */}
            <Box sx={{ textAlign: "center", mb: 3 }}>
              <Box
                sx={{
                  width: 64,
                  height: 64,
                  background: "linear-gradient(45deg, #2196F3 30%, #9C27B0 90%)",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  mx: "auto",
                  mb: 2,
                }}
              >
                <Box
                  sx={{
                    width: 32,
                    height: 32,
                    border: "2px solid white",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Box
                    sx={{
                      width: 12,
                      height: 12,
                      backgroundColor: "white",
                      borderRadius: "50%",
                      animation: "pulse 2s infinite",
                    }}
                  />
                </Box>
              </Box>
              <Typography
                variant="h4"
                component="h1"
                sx={{
                  fontWeight: "bold",
                  background: "linear-gradient(45deg, #2196F3 30%, #9C27B0 90%)",
                  backgroundClip: "text",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  mb: 1,
                }}
              >
                Network Portal
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Connect to your secure network dashboard
              </Typography>
            </Box>

            <form onSubmit={handleSubmit}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
                {error && (
                  <Alert severity="error" sx={{ display: "flex", alignItems: "center" }}>
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        backgroundColor: "error.main",
                        borderRadius: "50%",
                        mr: 1,
                        animation: "pulse 2s infinite",
                      }}
                    />
                    {error}
                  </Alert>
                )}

                <TextField
                  fullWidth
                  label="Network ID"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  variant="outlined"
                  placeholder="Enter your network ID"
                />

                <TextField
                  fullWidth
                  label="Access Key"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  variant="outlined"
                  placeholder="Enter your access key"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={() => setShowPassword(!showPassword)}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />

                <Alert severity="info" sx={{ fontSize: "0.875rem" }}>
                  <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        backgroundColor: "success.main",
                        borderRadius: "50%",
                        mr: 1,
                        animation: "pulse 2s infinite",
                      }}
                    />
                    <Typography variant="subtitle2" sx={{ color: "info.dark", fontWeight: "bold" }}>
                      Demo Network Access:
                    </Typography>
                  </Box>
                  <Box sx={{ fontFamily: "monospace", fontSize: "0.75rem", lineHeight: 1.5 }}>
                    <div>Super Admin: superadmin@example.com / super123</div>
                    <div>Team Admin: team1admin@example.com / team123</div>
                    <div>User: user1@example.com / user123</div>
                  </Box>
                </Alert>

                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  size="large"
                  disabled={loading}
                  sx={{
                    background: "linear-gradient(45deg, #2196F3 30%, #9C27B0 90%)",
                    "&:hover": {
                      background: "linear-gradient(45deg, #1976D2 30%, #7B1FA2 90%)",
                    },
                    py: 1.5,
                    fontWeight: "medium",
                  }}
                >
                  {loading ? (
                    <Box sx={{ display: "flex", alignItems: "center" }}>
                      <CircularProgress size={20} color="inherit" sx={{ mr: 1 }} />
                      Connecting to Network...
                    </Box>
                  ) : (
                    <Box sx={{ display: "flex", alignItems: "center" }}>
                      <Box
                        sx={{
                          width: 16,
                          height: 16,
                          backgroundColor: "white",
                          borderRadius: "50%",
                          mr: 1,
                          animation: "pulse 2s infinite",
                        }}
                      />
                      Connect to Network
                    </Box>
                  )}
                </Button>
              </Box>
            </form>
          </CardContent>
        </Card>
      </Box>
    </Box>
  )
}
