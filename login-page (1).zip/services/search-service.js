import { mockSearchData } from "../data/mock-data"

// Simulate API delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export const searchService = {
  async search(searchTerm) {
    await delay(500)

    if (!searchTerm.trim()) {
      return []
    }

    const results = mockSearchData.filter(
      (item) =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase()),
    )

    return results
  },
}
