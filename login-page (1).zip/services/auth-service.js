import { mockUsers } from "../data/mock-data"

// Simulate API delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export const authService = {
  async login(email, password) {
    await delay(1000) // Simulate API call

    const user = mockUsers.find((u) => u.email === email && u.password === password)

    if (user) {
      return { success: true, user }
    } else {
      return { success: false, error: "Invalid email or password" }
    }
  },

  async logout() {
    await delay(500)
    return { success: true }
  },

  async getCurrentUser() {
    await delay(300)
    const savedUser = localStorage.getItem("user")
    return savedUser ? JSON.parse(savedUser) : null
  },
}
