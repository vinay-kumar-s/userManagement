// Mock users database with team hierarchy
export const mockUsers = [
  // Super Admins (above team admins)
  {
    id: 1,
    email: "superadmin@example.com",
    password: "super123",
    role: "super_admin",
    name: "Super Admin",
    team: null,
  },
  { id: 2, email: "director@example.com", password: "director123", role: "super_admin", name: "Director", team: null },

  // Team Admins
  {
    id: 3,
    email: "team1admin@example.com",
    password: "team123",
    role: "team_admin",
    name: "Team 1 Admin",
    team: "Engineering",
  },
  {
    id: 4,
    email: "team2admin@example.com",
    password: "team123",
    role: "team_admin",
    name: "Team 2 Admin",
    team: "Marketing",
  },
  {
    id: 5,
    email: "team3admin@example.com",
    password: "team123",
    role: "team_admin",
    name: "Team 3 Admin",
    team: "Sales",
  },
  {
    id: 6,
    email: "team4admin@example.com",
    password: "team123",
    role: "team_admin",
    name: "Team 4 Admin",
    team: "Support",
  },
  {
    id: 7,
    email: "team5admin@example.com",
    password: "team123",
    role: "team_admin",
    name: "Team 5 Admin",
    team: "Finance",
  },

  // Regular Users
  { id: 8, email: "user1@example.com", password: "user123", role: "user", name: "John Engineer", team: "Engineering" },
  { id: 9, email: "user2@example.com", password: "user123", role: "user", name: "Jane Marketer", team: "Marketing" },
  { id: 10, email: "user3@example.com", password: "user123", role: "user", name: "Bob Salesperson", team: "Sales" },
  { id: 11, email: "user4@example.com", password: "user123", role: "user", name: "Alice Support", team: "Support" },
  { id: 12, email: "user5@example.com", password: "user123", role: "user", name: "Charlie Finance", team: "Finance" },
]

// Teams configuration
export const teams = [
  { id: 1, name: "Engineering", description: "Software development and technical operations", color: "blue" },
  { id: 2, name: "Marketing", description: "Brand promotion and customer acquisition", color: "green" },
  { id: 3, name: "Sales", description: "Revenue generation and client relations", color: "purple" },
  { id: 4, name: "Support", description: "Customer service and technical support", color: "orange" },
  { id: 5, name: "Finance", description: "Financial planning and accounting", color: "red" },
]

// Mock data for search
export const mockSearchData = [
  { id: 1, title: "React Documentation", type: "documentation", description: "Official React documentation" },
  { id: 2, title: "JavaScript Basics", type: "tutorial", description: "Learn JavaScript fundamentals" },
  { id: 3, title: "CSS Grid Guide", type: "guide", description: "Complete guide to CSS Grid" },
  { id: 4, title: "Node.js Tutorial", type: "tutorial", description: "Backend development with Node.js" },
  { id: 5, title: "Database Design", type: "course", description: "Learn database design principles" },
]

// Initial users with groups and permissions
export const initialUsers = [
  // Super Admins
  {
    id: 1,
    name: "Super Admin",
    email: "superadmin@example.com",
    role: "super_admin",
    team: null,
    groups: ["Super Administrators"],
    permissions: ["read", "write", "delete", "manage_users", "manage_groups", "system_admin", "manage_teams"],
  },
  {
    id: 2,
    name: "Director",
    email: "director@example.com",
    role: "super_admin",
    team: null,
    groups: ["Super Administrators"],
    permissions: ["read", "write", "delete", "manage_users", "manage_groups", "system_admin", "manage_teams"],
  },

  // Team Admins
  {
    id: 3,
    name: "Team 1 Admin",
    email: "team1admin@example.com",
    role: "team_admin",
    team: "Engineering",
    groups: ["Team Administrators", "Engineering Team"],
    permissions: ["read", "write", "delete", "manage_team_users"],
  },
  {
    id: 4,
    name: "Team 2 Admin",
    email: "team2admin@example.com",
    role: "team_admin",
    team: "Marketing",
    groups: ["Team Administrators", "Marketing Team"],
    permissions: ["read", "write", "delete", "manage_team_users"],
  },
  {
    id: 5,
    name: "Team 3 Admin",
    email: "team3admin@example.com",
    role: "team_admin",
    team: "Sales",
    groups: ["Team Administrators", "Sales Team"],
    permissions: ["read", "write", "delete", "manage_team_users"],
  },
  {
    id: 6,
    name: "Team 4 Admin",
    email: "team4admin@example.com",
    role: "team_admin",
    team: "Support",
    groups: ["Team Administrators", "Support Team"],
    permissions: ["read", "write", "delete", "manage_team_users"],
  },
  {
    id: 7,
    name: "Team 5 Admin",
    email: "team5admin@example.com",
    role: "team_admin",
    team: "Finance",
    groups: ["Team Administrators", "Finance Team"],
    permissions: ["read", "write", "delete", "manage_team_users"],
  },

  // Regular Users
  {
    id: 8,
    name: "John Engineer",
    email: "user1@example.com",
    role: "user",
    team: "Engineering",
    groups: ["Engineering Team"],
    permissions: ["read", "write"],
  },
  {
    id: 9,
    name: "Jane Marketer",
    email: "user2@example.com",
    role: "user",
    team: "Marketing",
    groups: ["Marketing Team"],
    permissions: ["read", "write"],
  },
  {
    id: 10,
    name: "Bob Salesperson",
    email: "user3@example.com",
    role: "user",
    team: "Sales",
    groups: ["Sales Team"],
    permissions: ["read"],
  },
  {
    id: 11,
    name: "Alice Support",
    email: "user4@example.com",
    role: "user",
    team: "Support",
    groups: ["Support Team"],
    permissions: ["read"],
  },
  {
    id: 12,
    name: "Charlie Finance",
    email: "user5@example.com",
    role: "user",
    team: "Finance",
    groups: ["Finance Team"],
    permissions: ["read"],
  },
]

export const initialGroups = [
  {
    id: 1,
    name: "Super Administrators",
    description: "Full system access across all teams",
    permissions: ["read", "write", "delete", "manage_users", "manage_groups", "system_admin", "manage_teams"],
    userCount: 2,
    team: null,
  },
  {
    id: 2,
    name: "Team Administrators",
    description: "Administrative access within their team",
    permissions: ["read", "write", "delete", "manage_team_users"],
    userCount: 5,
    team: null,
  },
  {
    id: 3,
    name: "Engineering Team",
    description: "Engineering team members",
    permissions: ["read", "write"],
    userCount: 2,
    team: "Engineering",
  },
  {
    id: 4,
    name: "Marketing Team",
    description: "Marketing team members",
    permissions: ["read", "write"],
    userCount: 2,
    team: "Marketing",
  },
  {
    id: 5,
    name: "Sales Team",
    description: "Sales team members",
    permissions: ["read"],
    userCount: 2,
    team: "Sales",
  },
  {
    id: 6,
    name: "Support Team",
    description: "Support team members",
    permissions: ["read"],
    userCount: 2,
    team: "Support",
  },
  {
    id: 7,
    name: "Finance Team",
    description: "Finance team members",
    permissions: ["read"],
    userCount: 2,
    team: "Finance",
  },
]

export const permissions = [
  { id: 1, name: "read", description: "View content and data" },
  { id: 2, name: "write", description: "Create and edit content" },
  { id: 3, name: "delete", description: "Remove content and data" },
  { id: 4, name: "manage_users", description: "Manage all user accounts" },
  { id: 5, name: "manage_team_users", description: "Manage users within own team" },
  { id: 6, name: "manage_groups", description: "Manage user groups" },
  { id: 7, name: "system_admin", description: "Full system administration" },
  { id: 8, name: "manage_teams", description: "Manage team structure and assignments" },
]
